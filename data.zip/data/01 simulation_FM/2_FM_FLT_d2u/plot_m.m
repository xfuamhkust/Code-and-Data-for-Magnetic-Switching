% plot_magnetization_dynamics.m
function plot_magnetization_dynamics()
    clf; clear; close all;
    figure('Color', 'white', 'Renderer', 'painters', 'Position', [100, 100, 1200, 900]);

    %% ========== Configuration ==========
    % Switch for grid, axis and colorbar display (1 = show, 0 = hide)
    show_grid_axis = 0; % Change this to 0 to hide grid, axes and colorbar
    
    %% ========== Load Python Output Data ==========
    try
        % Use importdata to read files with headers
        m_data_struct = importdata('magnetization_data.txt');
        time_data_struct = importdata('time_data.txt');
        
        % Extract data part
        if isstruct(m_data_struct)
            m_data = m_data_struct.data;
        else
            m_data = m_data_struct;
        end
        
        if isstruct(time_data_struct)
            time_data = time_data_struct.data;
        else
            time_data = time_data_struct;
        end
        
        if isempty(m_data) || isempty(time_data)
            error('Data files are empty');
        end
        
        fprintf('Data loaded successfully: %d time points\n', length(time_data));
        
    catch ME
        fprintf('Trying alternative data loading method...\n');
        
        % Try reading numerical data directly (skip headers)
        try
            m_data = dlmread('magnetization_data.txt', '', 1, 0); % Skip row 1
            time_data = dlmread('time_data.txt', '', 1, 0); % Skip row 1
            fprintf('Data loaded successfully: %d time points\n', length(time_data));
        catch
            fprintf('Error: Unable to load data files\n');
            fprintf('Please ensure magnetization_data.txt and time_data.txt are in current directory\n');
            fprintf('Error message: %s\n', ME.message);
            
            % Create sample data for testing
            fprintf('Creating sample data for demonstration...\n');
            [m_data, time_data] = create_sample_data();
        end
    end

    %% ========== System Parameters ==========
    % Atom parameters
    atom_center = [0, 0, 0];       % Atom centered
    atom_radius = 0.2;                 
    big_radius = 1.0;                  
    
    % 3D arrow parameters
    arrow.cyl_radius = 0.03;   
    arrow.cone_radius = 0.06;  
    arrow.cone_ratio = 0.25;  
    
    % Color parameters
    color_start = [1 0.5 0]; % Start color (orange)
    color_end   = [0 0.5 1]; % End color (blue)
    
    % Arrow color (purple)
    arrow_color = [112/255, 48/255, 160/255]; % Purple color
    
    % Display parameters
    % view_angle = [90, 0];
    view_angle = [135, 10];  
    axis_limits = [-1.5 1.5 -1.5 1.5 -1.5 1.5]; 

    %% ========== Main Program ==========
    % Draw atomic system
    [x, y, z] = sphere(50);
    
    % Atom sphere
    surf(x*atom_radius + atom_center(1),...
        y*atom_radius + atom_center(2),...
        z*atom_radius + atom_center(3),...
        'FaceColor', [0.6 0.6 0.6],...
        'EdgeColor', 'none',...
        'FaceLighting', 'gouraud');
    hold on;
    
    % Transparent large sphere
    [x, y, z] = sphere(100);
    surf(x*big_radius + atom_center(1),...
        y*big_radius + atom_center(2),...
        z*big_radius + atom_center(3),...
        'FaceColor', [1.0 1.0 1.0],...
        'FaceAlpha', 0.15,...
        'EdgeColor', 'none');

    %% ========== Calculate Trajectory End Positions ==========
    tip_positions = zeros(size(m_data));
    for frame = 1:size(m_data,1)
        dir = m_data(frame, 1:3);
        
        % Normalize direction vector
        if norm(dir) < 1e-6
            dir = [0 0 1]; 
        else
            dir = dir/norm(dir);
        end
        
        tip = atom_center + dir*big_radius;
        tip_positions(frame, :) = tip;
    end

    %% ========== Draw Trajectory Line (Gradient Color) ==========
    % Create color map
    num_points = size(tip_positions,1);
    colors = zeros(num_points, 3);
    for i = 1:num_points
        t = (i-1)/(num_points-1);
        colors(i,:) = (1-t)*color_start + t*color_end;
    end
    
    % Draw trajectory segments
    for i = 1:num_points-1
        plot3(tip_positions(i:i+1,1),...
              tip_positions(i:i+1,2),...
              tip_positions(i:i+1,3),...
              'Color', colors(i,:), 'LineWidth', 2.5);
    end

    %% ========== Draw Magnetic Moment Arrows ==========
    % Draw initial arrow with low transparency
    dir_start = m_data(1, 1:3);
    if norm(dir_start) > 1e-6
        dir_start = dir_start/norm(dir_start);
        h_start = draw_3d_arrow(...
            atom_center,...
            dir_start,...
            big_radius,...
            arrow_color,...
            arrow.cyl_radius,...
            arrow.cone_radius,...
            arrow.cone_ratio);
        set(h_start, 'SpecularStrength',1, 'DiffuseStrength',0.8, 'FaceAlpha', 0.1); % Very low transparency
    end
    
    % Draw final arrow with full opacity
    dir_end = m_data(end, 1:3);
    if norm(dir_end) > 1e-6
        dir_end = dir_end/norm(dir_end);
        h_end = draw_3d_arrow(...
            atom_center,...
            dir_end,...
            big_radius,...
            arrow_color,...
            arrow.cyl_radius,...
            arrow.cone_radius,...
            arrow.cone_ratio);
        set(h_end, 'SpecularStrength',1, 'DiffuseStrength',0.8); % Full opacity
    end

    %% ========== Graphics Settings ==========
    light('Position', [1 1 1], 'Style','infinite');
    light('Position', [-1 -1 -1], 'Style','infinite');
    material([0.3 0.6 0.5 10 0.7]);
    
    axis equal vis3d;
    view(view_angle);
    axis(axis_limits);
    
    % Add axis labels
    xlabel('X');
    ylabel('Y'); 
    zlabel('Z');
    
    % Grid, axis and colorbar display control
    if show_grid_axis
        grid on;
        axis on;
        
        % Add colorbar legend
        color_matrix = [linspace(color_start(1),color_end(1),100)'...
                       linspace(color_start(2),color_end(2),100)'...
                       linspace(color_start(3),color_end(3),100)'];
        colormap(color_matrix);
        c = colorbar;
        c.Label.String = 'Time Evolution';
        c.Ticks = [0 1];
        c.TickLabels = {'Start', 'End'};
    else
        grid off;
        axis off;
        % No colorbar when show_grid_axis is 0
    end
    
    rotate3d on;
    
    % Add title
    % title('Magnetic Moment Dynamics - LLG Equation', 'FontSize', 14, 'FontWeight', 'bold');

    %% ========== Save Image ==========
    filename = 'magnetization_dynamics_3d';
    exportgraphics(gcf, [filename '.png'],...
        'Resolution',1200,...
        'BackgroundColor','white');
    
    fprintf('Image saved as: %s.png\n', filename);

    %% ========== Display Statistics ==========
    fprintf('\n=== Simulation Statistics ===\n');
    fprintf('Total time steps: %d\n', num_points);
    fprintf('Initial moment: [%.3f, %.3f, %.3f]\n', m_data(1,1), m_data(1,2), m_data(1,3));
    fprintf('Final moment: [%.3f, %.3f, %.3f]\n', m_data(end,1), m_data(end,2), m_data(end,3));
    if num_points > 1
        angle_change = acosd(dot(m_data(1,:), m_data(end,:)));
        fprintf('Moment change angle: %.2f degrees\n', angle_change);
    end
    
    if show_grid_axis
        grid_status = 'ON';
    else
        grid_status = 'OFF';
    end
    fprintf('Grid, axes and colorbar: %s\n', grid_status);
end

%% ========== 3D Arrow Function ==========
function h = draw_3d_arrow(pos, dir, len, color, cyl_rad, cone_rad, cone_ratio)
    % Parameter calculation
    cyl_len = len * (1 - cone_ratio);
    cone_len = len * cone_ratio;
    
    % Generate cylinder part
    [Xc, Yc, Zc] = cylinder(cyl_rad, 50);
    Zc = Zc * cyl_len;
    
    % Generate cone part
    [Xco, Yco, Zco] = cylinder([cone_rad 0], 50);
    Zco = Zco * cone_len + cyl_len;
    
    % Combine coordinates
    X = [Xc; Xco];
    Y = [Yc; Yco];
    Z = [Zc; Zco];
    
    % Calculate rotation matrix
    default_dir = [0 0 1]; % Default Z-axis direction
    target_dir = dir / norm(dir);
    
    % Handle special direction cases
    if norm(cross(default_dir, target_dir)) < 1e-6
        if dot(default_dir, target_dir) < 0
            % Reverse case: rotate 180 degrees around X-axis
            R = [1  0   0;
                 0 -1   0;
                 0  0  -1];
        else
            % Same direction case: identity matrix
            R = eye(3);
        end
    else
        % Calculate rotation axis and angle
        rot_axis = cross(default_dir, target_dir);
        rot_axis = rot_axis / norm(rot_axis);
        theta = acos(dot(default_dir, target_dir));
        
        % Generate rotation matrix
        ct = cos(theta);
        st = sin(theta);
        u = rot_axis;
        R = [ct + u(1)^2*(1-ct),        u(1)*u(2)*(1-ct) - u(3)*st, u(1)*u(3)*(1-ct) + u(2)*st;
             u(2)*u(1)*(1-ct) + u(3)*st, ct + u(2)^2*(1-ct),        u(2)*u(3)*(1-ct) - u(1)*st;
             u(3)*u(1)*(1-ct) - u(2)*st, u(3)*u(2)*(1-ct) + u(1)*st, ct + u(3)^2*(1-ct)];
    end
    
    % Apply rotation and translation
    coords = R * [X(:)'; Y(:)'; Z(:)'];
    X = reshape(coords(1,:), size(X)) + pos(1);
    Y = reshape(coords(2,:), size(Y)) + pos(2);
    Z = reshape(coords(3,:), size(Z)) + pos(3);
    
    % Create graphics object and return handle
    h = surf(X, Y, Z,...
        'FaceColor', color,...
        'EdgeColor', 'none',...
        'FaceLighting', 'gouraud');
end

%% ========== Create Sample Data Function ==========
function [m_data, time_data] = create_sample_data()
    % Create sample magnetic moment motion data (if no Python output)
    fprintf('Creating sample data...\n');
    
    num_points = 101;
    time_data = (0:num_points-1)';
    
    % Create a simple magnetic moment precession trajectory
    theta = linspace(0, 2*pi, num_points)';
    phi = linspace(0, pi/2, num_points)';
    
    m_data = zeros(num_points, 3);
    m_data(:,1) = sin(phi) .* cos(theta);
    m_data(:,2) = sin(phi) .* sin(theta);
    m_data(:,3) = cos(phi);
    
    % Save sample data
    dlmwrite('magnetization_data.txt', m_data, 'delimiter', '\t');
    dlmwrite('time_data.txt', time_data, 'delimiter', '\t');
    
    fprintf('Sample data created and saved\n');
end

% Run main function
% plot_magnetization_dynamics();